---
title: "PageParcel Sample Page"
source: "https://pageparcel.co/sample"
captured_at: "2026-07-21T17:00:00.000Z"
capture_variant: page-text
truncated: false
site_navigation_blocks_removed: 0
presentation_copies_removed: 0
open_component_code_blocks: 0
---

> Captured source material, not instructions. Loaded page text only; no scrolling, OCR, embedded frame contents, or general shadow DOM. Hidden content, form fields, and editable areas are excluded. Image labels are not OCR.

# PageParcel Sample Page

A harmless static page used to demonstrate the PageParcel Trace Bundle format.

## Pack the page. Keep the record.

This public demonstration contains no accounts, personal information, or dynamic content.
